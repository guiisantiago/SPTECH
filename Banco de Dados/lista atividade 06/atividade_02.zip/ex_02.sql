create database campanha;

use campanha;

create table organizador(
idOrganizador int primary key auto_increment,
nome varchar(45),
email varchar(45)) auto_increment = 30;

alter table organizador add column fksupervisor int;
	alter table organizador add constraint fkorg
	foreign key (fksupervisor) 
references organizador(idOrganizador);

alter table organizador add column fkendereco int;
alter table organizador add constraint fkend
	foreign key (fkendereco)
references endereco(idEndereco);

create table doacao(
idCampanha int primary key auto_increment,
categoria varchar(45),
instituicao varchar(45),
instituicao2 varchar(45),
dtFinal date) auto_increment = 500;

alter table doacao add column fkorganizador int;
alter table doacao add constraint fkorgani
	foreign key (fkorganizador) 
references organizador(idOrganizador);

create table endereco(
idEndereco int primary key auto_increment,
nomerua varchar(45),
bairro varchar(45));

insert into organizador(nome, email)values
('Guilherme', 'gui@gmail.com'),
('Raissa', 'rai@hotmail.com'),
('Italo', 'italo@gmail.com'),
('Marcos', 'marcos@hotmail.com');

insert into doacao(categoria, instituicao, instituicao2, dtFinal) values
('Comida', 'Igreja', NULL, '2005-04-21'),
('Roupa', 'Escola', 'Faculdade', '2023-05-21'),
('Tenis', 'Empresa', 'Academica', '2020-10-21'),
('Produdo Higiênico', 'Casa', NULL, '2023-03-12');

insert into endereco(nomerua, bairro) values
('Teffe', 'Santa Maria'),
('Haddock Lobo', 'Gerty'),
('Ernesto Juliano', 'Barcelona'),
('Augusta', 'Paulista');

select * from organizador;

select * from doacao;

update organizador set fksupervisor = 33 
	where idOrganizador = 30;
    
update organizador set fksupervisor = 32 
	where idOrganizador = 31;
    
update organizador set fkendereco = 2 
	where idOrganizador = 30;
    
update organizador set fkendereco = 3 
	where idOrganizador = 31;
    
update organizador set fkendereco = 1 
	where idOrganizador = 32;
    
update organizador set fkendereco = 4
	where idOrganizador = 33;
    
update doacao set fkorganizador = 32 
	where idCampanha = 500;
    
update doacao set fkorganizador = 31
	where idCampanha = 501;

update doacao set fkorganizador = 33
	where idCampanha = 502;

update doacao set fkorganizador = 30
	where idCampanha = 503;

select * from organizador join doacao on fkorganizador = idOrganizador;

select * from organizador join doacao on fkorganizador = idOrganizador
	where nome = 'Guilherme';
    
select * from organizador as organizador left join organizador as supervisor on  organizador.idOrganizador =  supervisor.fksupervisor;

select  * from organizador as supervisor join organizador as organizador on organizador.idOrganizador = supervisor.fksupervisor
	where organizador.nome = 'Italo';
    
select * from organizador as organizador 
	left join doacao on fkorganizador = idOrganizador
    left join organizador as supervisor on organizador.idOrganizador = supervisor.fksupervisor;
    
select * from organizador as supervisor 
	join doacao on fkorganizador = idOrganizador
    join organizador as organizador on supervisor.fksupervisor  = organizador.idOrganizador
		where supervisor.nome = 'Raissa';



drop database campanha;
